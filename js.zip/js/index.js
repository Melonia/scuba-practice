$(function(){
	$(".bullet>li:nth-child(1)").click(function(){
		$("#main div div:nth-child(1) img").css("height","100%");
		$("#main div div:nth-child(2) img").css("height","0");
		$("#main div div:nth-child(3) img").css("height","0");
	});
	$(".bullet>li:nth-child(2)").click(function(){
		$("#main div div:nth-child(1) img").css("height","0");
		$("#main div div:nth-child(2) img").css("height","100%");
		$("#main div div:nth-child(3) img").css("height","0");
	});
	$(".bullet>li:nth-child(3)").click(function(){
		$("#main div div:nth-child(1) img").css("height","0");
		$("#main div div:nth-child(2) img").css("height","0");
		$("#main div div:nth-child(3) img").css("height","100%");
	});
});